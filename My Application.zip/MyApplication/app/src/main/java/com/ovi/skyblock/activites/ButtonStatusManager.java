package com.ovi.skyblock.activites;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;

public class ButtonStatusManager {
    private SharedPreferences sharedPreferences;
    private SharedPreferences.Editor editor;
    public ButtonStatusManager(Context context) {
        sharedPreferences = context.getSharedPreferences("button_status", Context.MODE_PRIVATE);
        editor = sharedPreferences.edit();
    }

    public static void saveButtonStatus(String buttonId, boolean status, Context context) {
        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(context);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putBoolean(buttonId, status);
        editor.apply();
    }

    public static boolean getButtonStatus(String buttonId, Context context) {
        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(context);
        return preferences.getBoolean(buttonId, false);
    }


}
