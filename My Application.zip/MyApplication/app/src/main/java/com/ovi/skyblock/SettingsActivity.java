package com.ovi.skyblock;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.ToggleButton;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatToggleButton;
import androidx.cardview.widget.CardView;

import com.ovi.skyblock.activites.ButtonStatusManager;
import com.ovi.skyblock.dialogs.SetAPIKeyDialog;
import com.ovi.skyblock.dialogs.SetUsernameDialog;
import com.google.android.material.button.MaterialButton;

public class SettingsActivity extends AppCompatActivity {
    Context context;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.settings);

        MaterialButton GoBack = findViewById(R.id.go_back);
        MaterialButton SetAPI = findViewById(R.id.api_key_set);
        MaterialButton SetUsername = findViewById(R.id.username_set);

        GoBack.setOnClickListener(view -> {
            finish();
            overridePendingTransition(R.anim.slide_up, R.anim.slide_down);
        });

        SetAPI.setOnClickListener(view -> {
            SetAPIKeyDialog.showDialog(this);
        });

        SetUsername.setOnClickListener(view -> {
            SetUsernameDialog.showDialog(this);
        });

        View activityMainLayout = getLayoutInflater().inflate(R.layout.activity_main, null);


        AppCompatToggleButton auction_toggle = findViewById(R.id.auction_toggle);
        auction_toggle.setChecked(ButtonStatusManager.getButtonStatus("auction_toggle", this));
        auction_toggle.setOnClickListener(view -> {


            CardView auctions = activityMainLayout.findViewById(R.id.Auctions);

            if (auction_toggle.isChecked()) {
                auctions.setVisibility(View.VISIBLE);
                ButtonStatusManager.saveButtonStatus("auction_toggle", true, this);
            } else {
                auctions.setVisibility(View.GONE);
                ButtonStatusManager.saveButtonStatus("auction_toggle", false, this);
            }
        });

        AppCompatToggleButton fetchur_toggle = findViewById(R.id.fetchur_toggle);
        fetchur_toggle.setOnClickListener(view -> {
            if (fetchur_toggle.isChecked()) {
                ButtonStatusManager.saveButtonStatus("fetchur_toggle", true, this);
            } else {
                CardView cardView = findViewById(R.id.Auctions);
                MainActivity.CardViewModifier.setCardViewVisibility(cardView, View.GONE);

                ButtonStatusManager.saveButtonStatus("fetchur_toggle", false, this);
            }
        });

        AppCompatToggleButton SBUpdates_toggle = findViewById(R.id.SBUpdates_toggle);
        SBUpdates_toggle.setChecked(ButtonStatusManager.getButtonStatus("SBUpdates_toggle", this));
        SBUpdates_toggle.setOnClickListener(view -> {
            CardView updates = activityMainLayout.findViewById(R.id.SBUpdatesButton);
            if (SBUpdates_toggle.isChecked()) {
                updates.setVisibility(View.VISIBLE);
                ButtonStatusManager.saveButtonStatus("SBUpdates_toggle", true, this);

            } else {
                updates.setVisibility(View.GONE);
                ButtonStatusManager.saveButtonStatus("SBUpdates_toggle", false, this);
            }
        });



    }
}
