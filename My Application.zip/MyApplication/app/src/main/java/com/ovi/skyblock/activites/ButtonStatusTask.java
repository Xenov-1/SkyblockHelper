package com.ovi.skyblock.activites;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;

import androidx.cardview.widget.CardView;

public class ButtonStatusTask {


    private SharedPreferences sharedPreferences;
    private SharedPreferences.Editor editor;
    public ButtonStatusTask (Context context) {
        sharedPreferences = context.getSharedPreferences("button_status", Context.MODE_PRIVATE);
        editor = sharedPreferences.edit();

    }
    public static void ButtonTaskMainActivity() {
    }



}
